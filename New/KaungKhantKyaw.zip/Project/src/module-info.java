/**
 * 
 */
/**
 * @author kaung
 *
 */
module Project {
	requires java.desktop;
	requires java.sql;
}