package MyShop;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

public class DeleteProduct extends JFrame implements ActionListener {
	
	Connection conn;
	String db = "jdbc:mysql://localhost:3306/myShop";
	String username = "root";
	String password = "root";
	ResultSet rs;
	Statement stmt;
	String sql;
	
	JPanel p1,p2,p3,p4;
	JButton findbtn,deletebtn,editbtn,canclebtn;
	JLabel l1,l2;
	JLabel proname,proqty,proprice,lname,lqty,lprice;
	JTextField tfind = new JTextField(10);
	int proId;
	String resname,resqty,resprice;
	
	public DeleteProduct(){
		
		this.setTitle("Delete Product");
		this.setSize(350,300);
		this.setLocation(600,150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		l1 = new JLabel("Enter product ID which you want to delete");
		l2 = new JLabel("Go back to Home Page");
		
		proname = new JLabel("Product Name");
		proqty = new JLabel("Quantity");
		proprice = new JLabel("Price");
		lname = new JLabel("Name");
		lqty = new JLabel("Quantity");
		lprice = new JLabel("Price");

		
		findbtn = new JButton("Find Product");
		findbtn.addActionListener(this);
		
		deletebtn = new JButton("Delete");
		deletebtn.addActionListener(this);
		
		editbtn = new JButton("Edit");
		editbtn.addActionListener(this);
		
		canclebtn = new JButton("Cancle");
		canclebtn.addActionListener(this);
		
		p1 = new JPanel();
		p1.setLayout(new GridLayout(2,1));
		p1.add(l1);
		p1.add(tfind);
		
		p2 = new JPanel();
		p2.setLayout(new GridLayout(1,3));
		p2.add(findbtn);
		p2.add(editbtn);
		p2.add(deletebtn);
		
		p4 = new JPanel();
		p4.setLayout(new GridLayout(3,2));
		p4.setBorder(BorderFactory.createEtchedBorder());
		p4.add(lname);
		p4.add(proname);
		p4.add(lqty);
		p4.add(proqty);
		p4.add(lprice);
		p4.add(proprice);	
		p4.setVisible(false);
		
		p3 = new JPanel();
		p3.setLayout(new GridLayout(3,1));
		p3.add(p4);
		p3.add(l2);
		p3.add(canclebtn);
			
		
		this.setLayout(new FlowLayout());
		this.add(p1);
		this.add(p2);
		this.add(p3);
		
		this.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		
		if(e.getSource() == findbtn) {
			
			String input = tfind.getText();
			int inputId;
			
			// Start Check input value is number or not
			if(input.matches(".*[a-z].*")) {
				JOptionPane.showMessageDialog(this, "Please Enter the valid ID");
			}else {
				
				// Start Find Method
				inputId = Integer.parseInt(input);
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection(db,username,password);
					PreparedStatement stmt = conn.prepareStatement("SELECT * FROM products WHERE id = ?");
					stmt.setInt(1, inputId);
					rs = stmt.executeQuery();
					
					while(rs.next()) {
						resname = rs.getString("productname");
						resqty = rs.getString("qty");
						resprice = rs.getString("price");
					}
					
					proname.setText(resname);
					proqty.setText(resqty);
					proprice.setText(resprice + " ks");
					p4.setVisible(true);
					
					stmt.close();
					conn.close();
					
					
					
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
			}
			// End Find Method
				
		}
		// End Check input value is number or not
			
		}else if(e.getSource() == deletebtn) {
			String input = tfind.getText();
			int inputId;
			inputId = Integer.parseInt(input);
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				conn = DriverManager.getConnection(db,username,password);
				stmt = conn.createStatement();
				sql = "DELETE FROM products WHERE id = '" + inputId + "'";
				stmt.executeUpdate(sql);
				JOptionPane.showMessageDialog(this, "Product successfully deleted");
				p4.setVisible(false);
				
				stmt.close();
				conn.close();
				
			} catch (ClassNotFoundException | SQLException e1) {
				e1.printStackTrace();
			}
			
			
		}else if(e.getSource() == editbtn){
			String input = tfind.getText();
			int inputId;
			inputId = Integer.parseInt(input);
			new EditProduct(inputId);
			dispose();
		}
		else {
			Admin adm = new Admin();
			adm.setVisible(true);
			dispose();
		}

	}

}
