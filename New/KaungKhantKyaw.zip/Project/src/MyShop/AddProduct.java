package MyShop;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class AddProduct extends JFrame implements ActionListener {
	
	Connection conn;
	String db = "jdbc:mysql://localhost:3306/myShop";
	String username = "root";
	String password = "root";
	ResultSet rs;
	Statement stmt;
	String sql;
	
	JPanel p1,p2;
	JLabel lname,lqty,lprice;
	JTextField tname,tqty,tprice;
	JButton savebtn,canclebtn,rtlgpgbtn;
	ButtonGroup gendergp;
	JRadioButton male,female;
	
	
	public AddProduct() {
		this.setTitle("Add Product");
		this.setSize(300,300);
		this.setLocation(600,150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		lname = new JLabel("Product Name");
		lqty = new JLabel("Quantity");
		lprice = new JLabel("Price");
		savebtn = new JButton("Save");
		savebtn.addActionListener(this);
		canclebtn = new JButton("Cancle");
		canclebtn.addActionListener(this);
		
		tname = new JTextField(10);
		tqty = new JTextField(10);
		tprice = new JTextField(10);

		
		p1 = new JPanel();
		p1.setLayout(new GridLayout(5, 2));
		p1.setBorder(BorderFactory.createEtchedBorder());
		
		p1.add(lname);
		p1.add(tname);
		p1.add(lqty);
		p1.add(tqty);
		p1.add(lprice);
		p1.add(tprice);
		p1.add(savebtn);
		p1.add(canclebtn);
		
		JLabel rtloginpage = new JLabel("Back to Admin Page");
		rtlgpgbtn = new JButton("Admin Page");
		rtlgpgbtn.addActionListener(this);
		
		this.setLayout(new FlowLayout());
		this.add(p1);
		this.add(rtloginpage);
		this.add(rtlgpgbtn);
		
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == savebtn) {
			
			String prodname = tname.getText();
			String proqty = tqty.getText();
			String proprice = tprice.getText();
			int productqty;
			int productprice;
			
			if(proqty.matches(".*[a-z].*") && proprice.matches(".*[a-z].*")) {
				JOptionPane.showMessageDialog(this, "Quantity and Price Must be Number");
			}else {
				productqty = Integer.parseInt(proqty);
				productprice = Integer.parseInt(proprice);
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection(db,username,password);
					PreparedStatement stmt = conn.prepareStatement("INSERT INTO products(productname,qty,price) VALUES(?,?,?)");
					stmt.setString(1, prodname);
					stmt.setInt(2, productqty);
					stmt.setInt(3, productprice);
					stmt.executeUpdate();
					JOptionPane.showMessageDialog(savebtn, "Welcome, "+ prodname + "  is successfully created");
					stmt.close();
					conn.close();
					
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			
		
			
		}else if(e.getSource() == canclebtn) {
			
			tname.setText("");
			tqty.setText("");
			tprice.setText("");
			
		}else {
			Admin adm = new Admin();
			adm.setVisible(true);
			dispose();
		}

	}

}
