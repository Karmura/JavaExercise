package MyShop;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class EdidPage extends JFrame implements ActionListener {
	
	Connection conn;
	String db = "jdbc:mysql://localhost:3306/myShop";
	String username = "root";
	String password = "root";
	Statement stmt;
	ResultSet rs;
	String sql;
	
	
	JPanel p1,p2;
	JLabel lname,lemail,lpass,lgender;
	JTextField tname,temail;
	JPasswordField tpass;
	JButton regbtn,canclebtn,rtlgpgbtn;
	ButtonGroup gendergp;
	JRadioButton male,female;
	
	int userId;
	String cusName;
	String cusEmail;
	String cusPass;
	String cusGender;
	
	
	public EdidPage(int customerid) {
		
		this.setTitle("Register");
		this.setSize(300,300);
		this.setLocation(500,150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		userId = customerid;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(db,username,password);
			PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE id = ?");
			stmt.setInt(1,userId);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				cusName = rs.getString("name");
				cusEmail = rs.getString("email");
				cusPass = rs.getString("password");
				cusGender = rs.getString("gender");
			}
			stmt.close();
			rs.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		lname = new JLabel("Name");
		lemail = new JLabel("Email");
		lpass = new JLabel("Password");
		lgender = new JLabel("Gender");
		regbtn = new JButton("Save");
		regbtn.addActionListener(this);
		canclebtn = new JButton("Cancle");
		canclebtn.addActionListener(this);
		
		tname = new JTextField(10);
		tname.setText(cusName);
		temail = new JTextField(10);
		temail.setText(cusEmail);
		tpass = new JPasswordField(10);
		tpass.setText(cusPass);
		tpass.setEchoChar('*');
		
		JPanel rdopanel = new JPanel();
		male = new JRadioButton("Male");
		female = new JRadioButton("Female");
		rdopanel.add(male);
		rdopanel.add(female);
		if(cusGender.equals("male")) {
			male.setSelected(true);
		}else {
			female.setSelected(true);
		}
		gendergp = new ButtonGroup();
		gendergp.add(male);
		gendergp.add(female);
		
		p1 = new JPanel();
		p1.setLayout(new GridLayout(5, 2));
		p1.setBorder(BorderFactory.createEtchedBorder());
		
		p1.add(lname);
		p1.add(tname);
		p1.add(lemail);
		p1.add(temail);
		p1.add(lpass);
		p1.add(tpass);
		p1.add(lgender);
		p1.add(rdopanel);
		p1.add(regbtn);
		p1.add(canclebtn);
		
		JLabel rtloginpage = new JLabel("Back to Login");
		rtlgpgbtn = new JButton("Login");
		rtlgpgbtn.addActionListener(this);
		
		this.setLayout(new FlowLayout());
		this.add(p1);
		this.add(rtloginpage);
		this.add(rtlgpgbtn);
		
		
		this.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==regbtn) {
			String rgname = tname.getText();
			String rgemail = temail.getText();
			String rgpass = tpass.getText();
			String rggender = male.isSelected() ? "male" : "female";
			
			if(rgname.equals("") || rgemail.equals("") || rgpass.equals("") || rggender.equals("")) {
				JOptionPane.showMessageDialog(this, "Please Enter the Informations");
			}
			else if(!(rgemail.contains("@gmail.com"))){
				JOptionPane.showMessageDialog(this, "Please enter the valid email");
			}
			else {
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection(db,username,password);
					if(cusEmail.equals(rgemail)) {
						PreparedStatement stmt = conn.prepareStatement("UPDATE users SET name=?, password=?, gender=? WHERE id=?");
						stmt.setString(1,rgname);
						stmt.setString(2,rgpass);
						stmt.setString(3,rggender);
						stmt.setInt(4, userId);
						stmt.executeUpdate();

						stmt.close();
						conn.close();
					}else {
						PreparedStatement stmt = conn.prepareStatement("UPDATE users SET name=?, email=?,password=?, gender=? WHERE id=?");
						stmt.setString(1,rgname);
						stmt.setString(2,rgemail);
						stmt.setString(3,rgpass);
						stmt.setString(4,rggender);
						stmt.setInt(5, userId);
						stmt.executeUpdate();
						
						stmt.close();
						conn.close();
					}
					
					JOptionPane.showMessageDialog(regbtn, "Welcome, " + rgname + " Your account successfull created!! Please Login again");
					dispose();
					LoginPage lp = new LoginPage();
					lp.setVisible(true);
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					if (e1 instanceof SQLIntegrityConstraintViolationException) {
						JOptionPane.showMessageDialog(this, "Email is already exists");
				    } else {
				    	e1.printStackTrace();
				    }
					
				}
				
			}
			
		}else if(e.getSource() == canclebtn) {
			tname.setText("");
			temail.setText("");
			tpass.setText("");
			gendergp.clearSelection();
		}else if(e.getSource() == rtlgpgbtn) {
			Customer lp = new Customer(userId);
			lp.setVisible(true);
			dispose();
		}

	}

}
