package MyShop;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginPage extends JFrame implements ActionListener {
	
	Connection conn;
	String db = "jdbc:mysql://localhost:3306/myShop";
	String username = "root";
	String password = "root";
	Statement stmt;
	String sql;
	ResultSet rs;
	
	JLabel lEmail,lPass,LReg;
	JButton loginbtn,canclebtn,registerbtn;
	JTextField tEmail;
	JPasswordField tPass;
	JPanel p1,p2;
	
	
	public LoginPage() {
		this.setTitle("Welcome to myShop");
		this.setSize(350,250);
		this.setLocation(550,250);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		lEmail = new JLabel("User Email");
		lPass = new JLabel("User Password");
		
		tEmail = new JTextField(15);
		tPass = new JPasswordField(15);
		tPass.setEchoChar('*');
		
		loginbtn = new JButton("Login");
		loginbtn.addActionListener(this);
		canclebtn = new JButton("Cancle");
		canclebtn.addActionListener(this);
		registerbtn = new JButton("Register");
		registerbtn.addActionListener(this);
		
		LReg = new JLabel("Don't you have account? You need to register first");
		registerbtn = new JButton("Register");
		registerbtn.addActionListener(this);	
		
		p1 = new JPanel();
		p2 = new JPanel();
		p1.setBorder(BorderFactory.createEtchedBorder());
		p1.setLayout(new GridLayout(4, 3));
		p1.add(lEmail);
		p1.add(tEmail);
		p1.add(lPass);
		p1.add(tPass);
		p1.add(loginbtn);
		p1.add(canclebtn);
		
		p2 = new JPanel();
		p2.add(p1);
		
		this.setLayout(new FlowLayout());
		this.add(p2);
		this.add(LReg);
		this.add(registerbtn);
		
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == loginbtn) {
			
			if(tEmail.equals("")) {
				JOptionPane.showMessageDialog(this ,"Please Enter the Emailaddress");
			}else if(tPass.getText().equals("")) {
				JOptionPane.showMessageDialog(this ,"Please Enter the Password");
			}else {
				String t1 = tEmail.getText();
				String t2 = tPass.getText();
				Boolean boo = false;
				
				try {
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection(db,username,password);
					stmt = conn.createStatement();
					
					sql = "SELECT * FROM users WHERE email='" + t1 + "' AND password='" + t2 + "'";
					rs = stmt.executeQuery(sql);
					
					while(rs.next()) {
						boo = true;
						int userid = rs.getInt("id");
						int isAdmin = rs.getInt("roleas");
						
						if(isAdmin != 1) {
							new Customer(userid);
							dispose();
						}else {
							new Admin();
							dispose();
						}
						
					}
					
					if(!boo) {
						JOptionPane.showMessageDialog(this, 
								"Email or Password is Incorrect. Please Login Again",
								"Error Message",0
								);
					}
				
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			
		}else if(e.getSource() == canclebtn) {
			
			tEmail.setText("");
			tPass.setText("");
			
		}else if(e.getSource() == registerbtn) {
			new RegisterPage();
			dispose();
		}

	}

}
