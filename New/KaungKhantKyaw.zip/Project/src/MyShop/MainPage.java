package MyShop;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class MainPage extends JFrame implements ActionListener {
	
	Connection conn;
	String db = "jdbc:mysql://localhost:3306/myShop";
	String username = "root";
	String password = "root";
	Statement stmt;
	String sql;
	ResultSet rs;
	
	JMenuBar menubar;
	JMenu menu;
	JMenuItem login,register;
	
	JPanel mainp;
	JLabel l1;
	JTextField name;
	JButton loginbtn, canclebtn;
	
	public MainPage() {
		this.setTitle("Welcome to myShop");
		this.setSize(600,500);
		this.setLocation(500,150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		menubar = new JMenuBar();
		menu = new JMenu("Login & Register");
		
		login = new JMenuItem("Login");
		login.setMnemonic('L');
		
		register = new JMenuItem("Register");
		register.setMnemonic('R');
		
		this.setJMenuBar(menubar);
		menubar.add(menu);
		menu.add(login);
		menu.add(register);
		
		
		login.addActionListener(this);
		register.addActionListener(this);
		
		
		
		// Start Product
		JTable table = new JTable();
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(db,username,password);
			stmt = conn.createStatement();
			
			sql = "SELECT * FROM products";
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			
			String[] colName = {"Product ID","Product Name","Quantity","Price"};
			model.setColumnIdentifiers(colName);
			while(rs.next()) {
				int productid = rs.getInt(1);
				String proid = String.valueOf(productid);
				String proname = rs.getString(2);
				String proqty = rs.getString(3);
				String proprice = rs.getString(4);
				
				String[] row = {proid,proname,proqty,proprice + " ks"};
				model.addRow(row);
				JScrollPane jp = new JScrollPane(table);
				this.add(jp, BorderLayout.CENTER);
			}
			stmt.close();
			conn.close();
		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		// End Product
		
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == login) {
			new LoginPage();
			dispose();
		}else if(e.getSource() == register) {
			new RegisterPage();
			dispose();
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MainPage();
	}

}
