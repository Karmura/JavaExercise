package MyShop;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class RegisterPage extends JFrame implements ActionListener {
	
	Connection conn;
	String db = "jdbc:mysql://localhost:3306/myShop";
	String username = "root";
	String password = "root";
	ResultSet rs;
	Statement stmt;
	String sql;
	
	JPanel p1,p2;
	JLabel lname,lemail,lpass,lgender;
	JTextField tname,temail;
	JPasswordField tpass;
	JButton regbtn,canclebtn,rtlgpgbtn;
	ButtonGroup gendergp;
	JRadioButton male,female,admin;
	
	
	public RegisterPage() {
		this.setTitle("Register");
		this.setSize(300,300);
		this.setLocation(500,150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		lname = new JLabel("Name");
		lemail = new JLabel("Email");
		lpass = new JLabel("Password");
		lgender = new JLabel("Gender");
		regbtn = new JButton("Save");
		regbtn.addActionListener(this);
		canclebtn = new JButton("Cancle");
		canclebtn.addActionListener(this);
		
		tname = new JTextField(10);
		temail = new JTextField(10);
		tpass = new JPasswordField(10);
		tpass.setEchoChar('*');
		
		JPanel rdopanel = new JPanel();
		male = new JRadioButton("Male");
		female = new JRadioButton("Female");
		rdopanel.add(male);
		rdopanel.add(female);
		gendergp = new ButtonGroup();
		gendergp.add(male);
		gendergp.add(female);
		
		JLabel ladmin = new JLabel("!! For ADMIN !!");
		JPanel foradmin = new JPanel();
		admin = new JRadioButton("Admin");
		foradmin.add(admin);
		
		
		p1 = new JPanel();
		p1.setLayout(new GridLayout(6, 2));
		p1.setBorder(BorderFactory.createEtchedBorder());
		
		p1.add(lname);
		p1.add(tname);
		p1.add(lemail);
		p1.add(temail);
		p1.add(lpass);
		p1.add(tpass);
		p1.add(lgender);
		p1.add(rdopanel);
		p1.add(ladmin);
		p1.add(foradmin);
		p1.add(regbtn);
		p1.add(canclebtn);
		
		JLabel rtloginpage = new JLabel("Back to Login");
		rtlgpgbtn = new JButton("Login");
		rtlgpgbtn.addActionListener(this);
		
		this.setLayout(new FlowLayout());
		this.add(p1);
		this.add(rtloginpage);
		this.add(rtlgpgbtn);
		
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==regbtn) {
			String rgname = tname.getText();
			String rgemail = temail.getText();
			String rgpass = tpass.getText();
			String rggender = male.isSelected() ? "male" : "female";
			int rgadmin = admin.isSelected() ? 1 : 0;
			
			if(rgname.equals("") || rgemail.equals("") || rgpass.equals("") || rggender.equals("")) {
				JOptionPane.showMessageDialog(this, "Please Enter the Informations");
			}
			else if(!(rgemail.contains("@gmail.com"))){
				JOptionPane.showMessageDialog(this, "Please enter the valid email");
			}
			else {
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection(db,username,password);
					
					PreparedStatement stmt = conn.prepareStatement("INSERT INTO users(name,email,password,gender,roleas) VALUES(?,?,?,?,?)");
					stmt.setString(1,rgname);
					stmt.setString(2,rgemail);
					stmt.setString(3,rgpass);
					stmt.setString(4,rggender);
					stmt.setInt(5,rgadmin);
					stmt.executeUpdate();
					JOptionPane.showMessageDialog(regbtn, "Welcome, " + rgname + " Your account successfull created!! Please Login again");
					dispose();
					stmt.close();
					conn.close();
					
					LoginPage lp = new LoginPage();
					lp.setVisible(true);
					
				} catch (ClassNotFoundException | SQLException e1) {
					
					if (e1 instanceof SQLIntegrityConstraintViolationException) {
						JOptionPane.showMessageDialog(this, "Email is already exists");
				    } else {
				    	e1.printStackTrace();
				    }
					
				} // End catch
				
			}
			
		}else if(e.getSource() == canclebtn) {
			tname.setText("");
			temail.setText("");
			tpass.setText("");
			gendergp.clearSelection();
		}else if(e.getSource() == rtlgpgbtn) {
			LoginPage lp = new LoginPage();
			lp.setVisible(true);
			dispose();
		}

	}

}
