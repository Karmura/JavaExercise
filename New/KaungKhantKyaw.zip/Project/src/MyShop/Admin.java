package MyShop;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Admin extends JFrame implements ActionListener {
	
	Connection conn;
	String db = "jdbc:mysql://localhost:3306/myShop";
	String username = "root";
	String password = "root";
	Statement stmt;
	String sql;
	ResultSet rs;
	
	JMenuBar menubar;
	JMenu menu;
	JMenuItem logout,addpd,editpd,deletepd;
	
	JPanel mainp;
	JLabel l1;
	JTextField name;
	JButton logoutbtn, canclebtn;
	
	public Admin() {
		
		this.setTitle("Welcome to myShop");
		this.setSize(600,500);
		this.setLocation(500,150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		menubar = new JMenuBar();
		menu = new JMenu("Add product");
		
		addpd = new JMenuItem("Add Products");
		addpd.setMnemonic('A');
		
		editpd = new JMenuItem("Edit Products");
		editpd.setMnemonic('E');
		
		deletepd = new JMenuItem("Edit & Delete Products");
		deletepd.setMnemonic('E');
		
		logout = new JMenuItem("Logout");
		logout.setMnemonic('L');
		
		this.setJMenuBar(menubar);
		menubar.add(menu);
		menu.add(addpd);
//		menu.add(editpd);
		menu.add(deletepd);
		menu.add(logout);
		
		addpd.addActionListener(this);
		editpd.addActionListener(this);
		deletepd.addActionListener(this);
		logout.addActionListener(this);
		
		
		
		// Start Product
		JTable table = new JTable();
		String takebtn = "Shop";
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(db,username,password);
			stmt = conn.createStatement();
			
			sql = "SELECT * FROM products";
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			
			String[] colName = {"ID","Product Name","Quantity","Price"};
			model.setColumnIdentifiers(colName);
			while(rs.next()) {
				int productid = rs.getInt(1);
				String proid = String.valueOf(productid);
				String proname = rs.getString(2);
				String proqty = rs.getString(3);
				String proprice = rs.getString(4);
				
				String[] row = {proid,proname,proqty,proprice+" ks"};
				model.addRow(row);
				JScrollPane jp = new JScrollPane(table);
				this.add(jp, BorderLayout.CENTER);
			}
			stmt.close();
			conn.close();
		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		// End Product
		
		this.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource() == logout) {
			new LoginPage();
			dispose();
		}else if(e.getSource() == addpd) {
			new AddProduct();
			dispose();
		}else if(e.getSource() == editpd) {
			new AddProduct();
			dispose();
		}else if(e.getSource() == deletepd) {
			new DeleteProduct();
		}

	}
	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		new Admin();
//	}

}
