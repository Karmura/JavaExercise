package MyShop;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Customer extends JFrame implements ActionListener {
	
	Connection conn;
	String db = "jdbc:mysql://localhost:3306/myShop";
	String username = "root";
	String password = "root";
	Statement stmt;
	String sql;
	ResultSet rs;
	
	JMenuBar menubar;
	JMenu menu;
	JMenuItem logout,edit,shop;
	
	JPanel mainp;
	JLabel l1;
	JTextField name;
	JButton logoutbtn, canclebtn;
	int customerid;
	
	// for buy
	JPanel shop1,shop2,review,btnpanel,moneypay;
	JLabel lproduct,lamount,lmoney,lcost,rproduct,ramount,rmoney,rpay;
	JTextField tproduct,tamount,tmoney;
	JButton confirmbtn,reviewbtn,paybtn;
	int cusId,productId,rsprice,rsqty;
	String rsname;
	
	public Customer(int userid) {
		
		this.setTitle("Welcome to myShop");
		this.setSize(600,750);
		this.setLocation(500,30);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		customerid = userid;
		
		mainp = new JPanel();
		
		menubar = new JMenuBar();
		menu = new JMenu("Customer Detail");
		
		shop = new JMenuItem("Buy Products");
		shop.setMnemonic('B');
		
		edit = new JMenuItem("Edit Profile");
		edit.setMnemonic('E');
		
		logout = new JMenuItem("Logout");
		logout.setMnemonic('L');
		
		this.setJMenuBar(menubar);
		menubar.add(menu);
		menu.add(shop);
		menu.add(edit);
		menu.add(logout);
		
		shop.addActionListener(this);
		edit.addActionListener(this);
		logout.addActionListener(this);
		
		lproduct = new JLabel("Enter product id");
		lamount = new JLabel("Enter the amount");
		lmoney = new JLabel("Total Cost");
		lcost = new JLabel("0.00");
		
		rproduct = new JLabel("Name");
		ramount = new JLabel("Amount");
		rmoney = new JLabel("Money");
		rpay = new JLabel("");
		
		tproduct = new JTextField(10);
		tamount = new JTextField(10);
		tmoney = new JTextField(10);
		
		confirmbtn = new JButton("Confirm");
		confirmbtn.addActionListener(this);
		paybtn = new JButton("Submit");
		paybtn.addActionListener(this);
		reviewbtn = new JButton("Review");
		reviewbtn.addActionListener(this);
		
		
		shop1 = new JPanel();
		shop1.setBorder(BorderFactory.createEtchedBorder());
		shop1.setLayout(new GridLayout(4,1));
		
		shop2 = new JPanel();
		shop2.setLayout(new GridLayout(2,3));
		shop2.add(lproduct);
		shop2.add(lamount);
		shop2.add(lmoney);
		shop2.add(tproduct);
		shop2.add(tamount);
		shop2.add(lcost);
		
		
		btnpanel = new JPanel();
		btnpanel.setLayout(new GridLayout(1,2));
		btnpanel.add(confirmbtn);
		btnpanel.add(reviewbtn);
		
		
		JLabel lmoneyinput = new JLabel("Enter the Charge");
		moneypay = new JPanel();
		moneypay.setLayout(new GridLayout(1,3));
		moneypay.add(lmoneyinput);
		moneypay.add(tmoney);
		moneypay.add(paybtn);
		
		moneypay.setVisible(false);
		
		review = new JPanel();
		review.setBorder(BorderFactory.createEtchedBorder());
		review.setLayout(new GridLayout(1,4));
		review.add(rproduct);
		review.add(ramount);
		review.add(rmoney);
		review.add(rpay);
		
		review.setVisible(false);
		
		shop1.add(shop2);
		shop1.add(btnpanel);
		shop1.add(review);
		shop1.add(moneypay);
		
		
		
		// Start Product
		JTable table = new JTable();
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(db,username,password);
			stmt = conn.createStatement();
			
			sql = "SELECT * FROM products";
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			
			String[] colName = {"Product ID","Product Name","Quantity","Price"};
			model.setColumnIdentifiers(colName);
			while(rs.next()) {
				int productid = rs.getInt(1);
				String proid = String.valueOf(productid);
				String proname = rs.getString(2);
				String proqty = rs.getString(3);
				String proprice = rs.getString(4);
				
				String[] row = {proid,proname,proqty,proprice + " ks"};
				model.addRow(row);
				JScrollPane jp = new JScrollPane(table);
				mainp.add(jp, BorderLayout.CENTER);
				
			}
			
			stmt.close();
			conn.close();
			mainp.add(shop1);
			
			
			
		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		// End Product
		
		
		this.add(mainp);
		this.setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == logout) {
			new LoginPage();
			dispose();
		}else if(e.getSource() == edit) {
			new EdidPage(customerid);
			dispose();
		}else if(e.getSource() == confirmbtn) {
			
			String proid = tproduct.getText();
			String proamount = tamount.getText();
			String cuscost = lcost.getText();
			
			if(proid.equals("")) {
				JOptionPane.showMessageDialog(this, "Please select the product that you want to buy");
			}else if(proamount.equals("")) {
				JOptionPane.showMessageDialog(this, "Please enter the amount that you want to buy");
			}else if(proid.matches(".*[a-z].*") && proamount.matches(".*[a-z].*")) {
				JOptionPane.showMessageDialog(this, "Please Enter the number");
			}else {
				int pid = Integer.parseInt(proid); // input product id
				int amt = Integer.parseInt(proamount); // input amount quantity
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection(db,username,password);
					PreparedStatement stmt = conn.prepareStatement("SELECT * FROM products WHERE id = ?");
					stmt.setInt(1, pid);
					rs = stmt.executeQuery();
					while(rs.next()) {
						rsname = rs.getString("productname");
						rsprice = rs.getInt("price");
						rsqty = rs.getInt("qty");
					}
					
					int total = rsprice * amt; // total amount (price * take amount)
					int quentity =  rsqty - amt; // left value (qty - take amount)
					sql = "SELECT EXISTS(SELECT 1 FROM products WHERE id =" + pid +");";
					rs = stmt.executeQuery();

					if(amt > rsqty) {
						JOptionPane.showMessageDialog(this, "Sorry! We have only " + rsqty + " products");
					}else if(rsqty == 0) {
						JOptionPane.showMessageDialog(this, "Sorry! We have are out of stock");
					}else if(!(rs.next() == true)) {
						JOptionPane.showMessageDialog(this, "Please enter the valid products");
					}else {
						String takeqty = String.valueOf(amt);
						String totalprice = String.valueOf(total);
						
						rproduct.setText(rsname);
						ramount.setText(takeqty);
						rmoney.setText(totalprice + " ks");
						lcost.setText(totalprice + " ks");
						
						moneypay.setVisible(true);
						stmt.close();
						conn.close();
					}	
					
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
				
			}
			
			
		}else if(e.getSource() == reviewbtn) {
			
			review.setVisible(true);
			moneypay.setVisible(true);
			
		}else if(e.getSource() == paybtn) {

			String charge = tmoney.getText();
			String proid = tproduct.getText();
			String proamount = tamount.getText();
			String cuscost = lcost.getText();
			
			if(charge.equals("")) {
				JOptionPane.showMessageDialog(this, "Please enter the charge");
			}else if(charge.matches(".*[a-z].*")) {
				JOptionPane.showMessageDialog(this, "Please enter the numbers");
			}else {
				
				int icharge = Integer.parseInt(charge);
				int pid = Integer.parseInt(proid); // input product id
				int amt = Integer.parseInt(proamount); // input amount quantity
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection(db,username,password);
					PreparedStatement stmt = conn.prepareStatement("SELECT * FROM products WHERE id = ?");
					stmt.setInt(1, pid);
					rs = stmt.executeQuery();
					while(rs.next()) {
						rsname = rs.getString("productname");
						rsprice = rs.getInt("price");
						rsqty = rs.getInt("qty");
					}
					
					int total = rsprice * amt; // total amount (price * take amount)
					int quentity =  rsqty - amt; // left value (qty - take amount)
					
					if(icharge < total) {
						JOptionPane.showMessageDialog(this, "Not enough money");
					}else {
						int refound = icharge - total;
						String srefound = String.valueOf(refound);
						rpay.setText(srefound);
						
						stmt = conn.prepareStatement("UPDATE products SET qty=? WHERE id=?");
						stmt.setInt(1, quentity);
						stmt.setInt(2, pid);
						stmt.executeUpdate();
						
						stmt = conn.prepareStatement("INSERT INTO results(user_id,productname,qty,totalprice,product_id,refound) VALUES( ?,?,?,?,?,?)");
						stmt.setInt(1, customerid);
						stmt.setString(2, rsname);
						stmt.setInt(3, amt);
						stmt.setInt(4, total);
						stmt.setInt(5, pid);
						stmt.setInt(6, refound);
						stmt.executeUpdate();
						
						String msg = "Thank you " + 
								"\n Product Name : " + rsname + 
								"\n Price : " + rsprice + " ks" +
								"\n Quentity : " + amt + 
								"\n Total Cost : " + total + " ks" +
								"\n Charge : " + icharge + " ks" +
								"\n ---------------------------------" +
								"\n Refound : " + refound +  " ks";
						
						JOptionPane.showMessageDialog(this, msg, "Your Bill ", JOptionPane.INFORMATION_MESSAGE);
						dispose();
						new Customer(customerid);
						
						
						stmt.close();
						conn.close();
					}
					
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
				
				
			}
			
		}

	}
	

}
